import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons, FontAwesome5 } from "@expo/vector-icons";

export default function Disciplinas() {
  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>Home</Text>

        <View style={styles.box}>
          <FontAwesome5 name="book" size={55} color="#2b4c80" style={styles.boxIcon} />
          <Text style={styles.boxTitle}>Programação{"\n"}para Dispositivos</Text>

          {/* Conteúdos */}
          <Text style={styles.sectionLabel}>Conteúdos</Text>
          <View style={styles.pdfRow}>
            <PdfItem title="Tags HTML" />
            <PdfItem title="Configurando o back" />
            <PdfItem title="Configurando o front" />
          </View>

          {/* Avisos */}
          <Text style={styles.sectionLabel}>Avisos</Text>
          <View style={styles.notice}>
            <Text style={styles.noticeText}>Hoje não haverá aula, repor-nos-emos</Text>
          </View>

          {/* Aulas repositório */}
          <Text style={styles.sectionLabel}>Aulas repositórias</Text>
          <TouchableOpacity style={styles.videoBox}>
            <Ionicons name="logo-youtube" size={30} color="#000" />
            <Text style={styles.videoText}>aula2yt...</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Menu inferior fixo */}
      <SafeAreaView style={styles.footerSafeArea} edges={["bottom"]}>
        <View style={styles.footer}>
          <TouchableOpacity
            accessible
            accessibilityLabel="Disciplinas"
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.footerItem}
          >
            <Ionicons name="clipboard-outline" size={22} color="#2b4c80" />
            <Text style={styles.footerText}>Disciplinas</Text>
          </TouchableOpacity>

          <TouchableOpacity
            accessible
            accessibilityLabel="Avisos"
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.footerItem}
          >
            <Ionicons name="megaphone-outline" size={22} color="#2b4c80" />
            <Text style={styles.footerText}>Avisos</Text>
          </TouchableOpacity>

        <TouchableOpacity style={styles.footerItem}>
          <Ionicons name="time-outline" size={26} color="#2b4c80" />
          <Text style={styles.footerText}>Horários</Text>
        </TouchableOpacity>

          <TouchableOpacity
            accessible
            accessibilityLabel="Mensagens"
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.footerItem}
          >
            <MaterialCommunityIcons name="message-text-outline" size={22} color="#2b4c80" />
            <Text style={styles.footerText}>Mensagens</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

function PdfItem({ title }: { title: string }) {
  return (
    <TouchableOpacity style={styles.pdfItem}>
      <MaterialCommunityIcons name="file-pdf-box" size={45} color="red" />
      <Text style={styles.pdfText}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#fff",
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 100,
  },
  title: {
    fontSize: 22,
    fontWeight: "600",
    marginBottom: 15,
  },
  box: {
    backgroundColor: "#eaf0ff",
    borderRadius: 16,
    padding: 20,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  boxIcon: {
    alignSelf: "center",
    marginBottom: 10,
  },
  boxTitle: {
    textAlign: "center",
    fontWeight: "bold",
    fontSize: 16,
    color: "#2b4c80",
    marginBottom: 20,
  },
  sectionLabel: {
    fontWeight: "bold",
    fontSize: 14,
    marginBottom: 10,
    marginTop: 10,
    color: "#2b4c80",
  },
  pdfRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  pdfItem: {
    alignItems: "center",
    width: "30%",
  },
  pdfText: {
    fontSize: 12,
    textAlign: "center",
  },
  notice: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 10,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  noticeText: {
    fontSize: 13,
    color: "#333",
  },
  videoBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 10,
    width: "70%",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  videoText: {
    marginLeft: 8,
    color: "#333",
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderColor: "#ccc",
    paddingVertical: 8,
    position: "relative",
    left: 0,
    right: 0,
    minHeight: 56,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 8,
  },
  footerItem: {
    alignItems: "center",
  },
  footerText: {
    fontSize: 12,
    color: "#2b4c80",
    marginTop: 3,
  },
  footerSafeArea: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#fff',
  },
});
