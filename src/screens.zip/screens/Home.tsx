import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons, FontAwesome5 } from "@expo/vector-icons";

import { useNavigation } from "@react-navigation/native";

export default function Home() {
  // hook de navegação
  const navigation = useNavigation<any>();

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>Home</Text>

        {/* Engenharia de Software */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Engenharia de Software</Text>
          <Text style={styles.subtitle}>Disciplinas Ativas</Text>

          <View style={styles.grid}>
            <Card key="programacao" icon={<FontAwesome5 name="book" size={28} color="#000" />} title="Programação para Dispositivos" />
            <Card key="gestao" icon={<MaterialIcons name="engineering" size={28} color="#000" />} title="Gestão de Projetos" />
            <Card key="rede" icon={<FontAwesome5 name="network-wired" size={28} color="#000" />} title="Rede de Computadores" />
            <Card key="calculo1" icon={<FontAwesome5 name="calculator" size={28} color="#000" />} title="Cálculo 1" />
            <Card key="arquitetura" icon={<MaterialIcons name="architecture" size={28} color="#000" />} title="Arquitetura de Software" />
            <Card key="ed" icon={<FontAwesome5 name="database" size={28} color="#000" />} title="Estrutura de Dados" />
          </View>
        </View>

        {/* Horários */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Horários</Text>
          <View style={styles.profile}>
            <Ionicons name="person-circle" size={60} color="#000" />
            <Text style={styles.name}>Elikson Tavares</Text>
            <TouchableOpacity>
              <Text style={styles.link}>Ver conteúdo</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.scheduleBox}>
            <Text style={styles.scheduleTitle}>Programação para Dispositivos</Text>
            <View style={styles.scheduleRow}>
              <DayBox day="Terça" code="ESW0GNA" time="20:30 - 21:20" room="E-30" />
              <DayBox day="Quinta" code="ESW0GNA" time="20:30 - 21:20" room="E-30" />
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Menu fixo inferior */}
        <SafeAreaView edges={["bottom"]} style={styles.footerSafeArea}>
          <View style={styles.footer}>
            <TouchableOpacity
              accessible
              accessibilityLabel="Disciplinas"
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              style={styles.footerItem}
              onPress={() => navigation.navigate("Disciplinas")} // rota por nome
            >
              <Ionicons name="book-outline" size={24} color="#2b4c80" />
              <Text style={styles.footerText}>Disciplinas</Text>
            </TouchableOpacity>
    
          <TouchableOpacity
            accessible
            accessibilityLabel="Avisos"
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.footerItem}
          >
            <Ionicons name="megaphone-outline" size={24} color="#2b4c80" />
            <Text style={styles.footerText}>Avisos</Text>
          </TouchableOpacity>

          <TouchableOpacity
            accessible
            accessibilityLabel="Horários"
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.footerItem}
          >
            <Ionicons name="time-outline" size={24} color="#2b4c80" />
            <Text style={styles.footerText}>Horários</Text>
          </TouchableOpacity>

          <TouchableOpacity
            accessible
            accessibilityLabel="Notícias"
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.footerItem}
          >
            <Ionicons name="newspaper-outline" size={24} color="#2b4c80" />
            <Text style={styles.footerText}>Notícias</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

// COMPONENTES AUXILIARES
function Card({ icon, title }: { icon: React.ReactNode; title: string }) {
  return (
    <TouchableOpacity style={styles.card}>
      {icon}
      <Text style={styles.cardText}>{title}</Text>
    </TouchableOpacity>
  );
}

function DayBox({ day, code, time, room }: { day: string; code: string; time: string; room: string }) {
  return (
    <View style={styles.dayBox}>
      <Text style={styles.dayText}>{day}</Text>
      <Text style={styles.dayDetail}>{code}</Text>
      <Text style={styles.dayDetail}>{time}</Text>
      <Text style={styles.dayDetail}>{room}</Text>
    </View>
  );
}

// ESTILOS
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#fff",
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 90, // espaço para o footer
  },
  title: {
    fontSize: 22,
    fontWeight: "600",
    marginBottom: 10,
  },
  section: {
    backgroundColor: "#f9faff",
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#2b4c80",
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: "#4a4a4a",
    marginBottom: 10,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  card: {
    backgroundColor: "#eaf0ff",
    width: "48%",
    borderRadius: 10,
    padding: 15,
    alignItems: "center",
    marginBottom: 10,
  },
  cardText: {
    fontSize: 13,
    textAlign: "center",
    marginTop: 5,
  },
  profile: {
    alignItems: "center",
    marginBottom: 15,
  },
  name: {
    fontSize: 16,
    fontWeight: "bold",
  },
  link: {
    color: "#1a73e8",
    marginTop: 5,
  },
  scheduleBox: {
    backgroundColor: "#eaf0ff",
    padding: 10,
    borderRadius: 10,
  },
  scheduleTitle: {
    textAlign: "center",
    fontWeight: "bold",
    marginBottom: 10,
    fontSize: 14,
  },
  scheduleRow: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  dayBox: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 8,
    alignItems: "center",
    width: "45%",
  },
  dayText: {
    fontWeight: "bold",
    color: "#2b4c80",
  },
  dayDetail: {
    fontSize: 12,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderColor: "#ccc",
    paddingVertical: 8,
    position: "relative",
    left: 0,
    right: 0,
    minHeight: 56,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  footerSafeArea: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#fff',
  },
  footerItem: {
    alignItems: "center",
  },
  footerText: {
    fontSize: 12,
    color: "#2b4c80",
    marginTop: 3,
  },
});
